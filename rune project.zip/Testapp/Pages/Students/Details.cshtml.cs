using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Http;
using System.Net.Http.Json;
using Testapp.Models;

namespace Testapp.Pages.Students
{
    public class DetailsModel : PageModel
    {

        public int Id { get; set; }

        public Student? Student { get; set; }

        public IActionResult OnGet(int id)
        {
            var client = new HttpClient();
            return Page();
        }
    }
}
