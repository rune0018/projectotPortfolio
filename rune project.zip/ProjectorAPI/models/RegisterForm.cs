﻿namespace ProjectorAPI.models
{ 
    public class RegisterForm
    {
        public string username { get; set; }
        public string password { get; set; }
        public string id { get; set; }
    }
}
